file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (GROZA_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (M416_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (UZI_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (M16A4_Range = 999)
    cycle : 
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (野牛_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (蜜罐_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (AKM_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (SCAL_R_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (PKM_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (MG3_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (P18C_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (M762_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (MK47_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (M249_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (S686_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (GROZA_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (P90_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (UMP45_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (VAL_Range = 999)
    cycle : 
}
file script(){
    public  :
     Print script; (firearms Range = 999)
    public  :
       Print script; (Vector_Range = 999)
    cycle : 