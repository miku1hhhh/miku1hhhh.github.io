System.out.println();
      for(:){
	  }AimAssist = 999; E
	    capture.cycle; E();
	  for(:){
	  }AimAssist = head; O
	    capture.cycle; O()
try
{
}catch(.E.O)
{
}