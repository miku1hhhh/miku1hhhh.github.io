File Script(){
    public：
      Print Script;(The range of physical damage caused by firearms to characters="999")
    public：
      Print Script;(The range of head damage caused by firearms to characters="999")
    public：
      Print Script;(GROZA_Range="999")
    circulate：
}