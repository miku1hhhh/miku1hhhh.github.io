{
   "Head dynamic tracking":{
      "Gyroscope tracking":"Lock",
      "Strength":999999,
      "Power":"Max",
      "strength":999999,
      "intensity":"Max",
     "Static tracking"",":"360°×360°"
      "Dynamictracking"",":"360°×360°"
      "Character Movement Tracking"",":"360°×360
   },
   "FireEvent":{
      "Trigger":"PlayerFires"
   },
   "MovementEvent":{
      "Trigger":"BotMoves",
      "Action":"TrackHead"
   },
   "NoZoom":{
      "Speed":"forcedLock",
      "Strength":9999.0,
      "Power":"Max",
            "strength":999999,
      "intensity":"Max",
      "Statictracking":"360°×360°  
          "Dynamictracking"",":"360°×360°"
      "Character Movement Tracking"",":"360°×360
   }
}