import java.util.Scanner;
public data();
 public { M416 damage value;
            Damage value = 800000000,
            5000000000: true
        M416 bullet rate of fire;
            5.56 bullet firing speed = 0/s
            0/s: true
        }