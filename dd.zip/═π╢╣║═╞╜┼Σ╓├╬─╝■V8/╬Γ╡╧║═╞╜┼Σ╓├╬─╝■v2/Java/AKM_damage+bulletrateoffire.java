import java.util.Scanner;
public data();
 public { AKM damage value;
            Damage value = 8000000000,
            50000000000: true
        AKM bullet rate of fire;
            5.56 bullet firing speed = 0/s
            0/s: true
        }