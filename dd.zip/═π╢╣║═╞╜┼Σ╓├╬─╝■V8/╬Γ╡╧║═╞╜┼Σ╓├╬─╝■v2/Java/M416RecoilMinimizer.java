public class M416RecoilMinimizer {

  public static void main(String[] args) {
 
    double recoilAmount = 9.0;
    double recoilReduction = 0.5; 
    
    double minRecoil = calculateMinRecoil(recoilAmount, recoilReduction);
    
    System.out.println("The minimum recoil of the M416 is: " + minRecoil);
  }
  
  private static double calculateMinRecoil(double recoilAmount, double recoilReduction) {
    double minRecoil = recoilAmount;
    
    for (int i = 0; i < 10; i++) { 
        minRecoil = minRecoil * recoilReduction;
    }
    
    return minRecoil;
  }
}