public class M416BulletDamageMaximizer {

  public static void main(String[] args) {

    double bulletDamage = 42.0; 
    
    double maxBulletDamage = calculateMaxBulletDamage(bulletDamage);
    
    System.out.println("The maximum increased bullet damage of the M416 is: " + maxBulletDamage);
  }
  
  private static double calculateMaxBulletDamage(double bulletDamage) {
    double maxBulletDamage = 0.0;
    
 
    
    maxBulletDamage = bulletDamage * 1.5; 
    
    return maxBulletDamage;
  }
}