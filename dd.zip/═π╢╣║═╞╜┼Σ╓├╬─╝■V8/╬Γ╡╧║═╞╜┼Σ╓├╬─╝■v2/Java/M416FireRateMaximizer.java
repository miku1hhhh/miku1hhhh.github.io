public class M416FireRateMaximizer {

  public static void main(String[] args) {

    double fireRate = 0.085; 
    
    double maxFireRate = calculateMaxFireRate(fireRate);
    
    System.out.println("The maximum increased fire rate of the M416 is: " + maxFireRate + " seconds per shot");
  }
  
  private static double calculateMaxFireRate(double fireRate) {
    double maxFireRate = 0.0;
    
    
    
    maxFireRate = fireRate * 0.8; 
    
    return maxFireRate;
  }
}
