{
  name: ["com.tencent.tmgp.pubgmhd"]
   <DOCTYPE Java>
   <Java>
   <Function>"bullet tracking"</Function
   <target>"head"</target>
   <execute>com.tencent.tmgp.pubgmhd<"execute">
"Bullet model=999
"Model figure range=999
"Headform Scope=999
"Body type range=999
"Body range=999
"Head range=999
"Character range=999
"Leg range==999
"Hit range when characters are in motion=999
"Area size of character model=999
"Character strike area size=999
"Character hit rate=999
"Area range of characters hit=999
"Bullet hit area=999
"Firing trigger strike effect=999
"Hit area of classic flame=999
"Hit range of all guns=999
                     }:"execute"
             <Java>