public class M416BulletRangeMaximizer {

  public static void main(String[] args) {

    double bulletRange = 500.0; 
    
    double maxBulletRange = calculateMaxBulletRange(bulletRange);
    
    System.out.println("The maximum increased bullet range of the M416 is: " + maxBulletRange);
  }
  
  private static double calculateMaxBulletRange(double bulletRange) {
    double maxBulletRange = 0.0;
    

    
    maxBulletRange = bulletRange * 1.2; 
    
    return maxBulletRange;
  }
}